
console.log("Welcome to XcelCoin Official Site!");
